Credit to LukeYui for the original Randomiser. You can find it here: https://github.com/LukeYui/DS3-Item-Randomiser-OS

Cinders requires a custom version of the randomiser, so to use the Item Randomiser with Cinders, drag and drop the files within this directory in to the DARK SOULS III/Game/ directory.

Use the Item Order Randomiser.exe to generate new seeds, use New and then Custom List, entering a number bigger than 1700 (the number needs to be atleast the number of lines in Data_Item_List, bigger just ensures that is the case). 
