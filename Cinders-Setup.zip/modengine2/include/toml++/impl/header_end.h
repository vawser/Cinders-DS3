//# {{
#ifdef __INTELLISENSE__
#include "preprocessor.h"
#endif
//# }}
#ifdef _MSC_VER
#pragma pop_macro("min")
#pragma pop_macro("max")
#endif
TOML_POP_WARNINGS;
